This software is licensed under the GPLv3 and AGPLv3

GPLv3 : https://www.gnu.org/licenses/gpl-3.0.en.html
AGPLv3 : https://www.gnu.org/licenses/agpl-3.0.en.html