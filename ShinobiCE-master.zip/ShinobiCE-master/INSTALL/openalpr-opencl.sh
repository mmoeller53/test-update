sudo apt-get update && sudo apt install -y openalpr openalpr-daemon openalpr-utils libopenalpr-dev

git clone https://github.com/openalpr/openalpr.git