"use strict";

function error(message) {
  console.error(message);
  console.trace();
}

module.exports = error;
