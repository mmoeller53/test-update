var fs = require('fs');
fs.readFileSync(__dirname+'/.git/logs/')